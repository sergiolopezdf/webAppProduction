import React from 'react';

export default class Index extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {

        return (
            <div className="bodyWrapper">
                <h1>Welcome to WebApp</h1>
            </div>
        );

    }
}
